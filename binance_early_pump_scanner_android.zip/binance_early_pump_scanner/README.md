# Binance Futures Early Pump Scanner (1H Swing)

A mobile-friendly Streamlit dashboard for scanning Binance USDⓈ-M USDT perpetual markets.

## What it does
- Loads the complete set of currently trading USDT-margined perpetual symbols.
- Ranks the most liquid symbols by 24-hour quote volume, then deeply analyses a configurable subset (default 60).
- Uses the last fully closed 1-hour candle for indicators.
- Scores volume expansion, 1-hour open-interest change (where available), EMA trend, RSI, resistance proximity/breakout, funding rate, and BTC trend.
- Shows the top 10 candidates, indicative entry/stop/targets, CSV export, and optional Telegram message sending.

## Important limitation
Scanning every symbol for every indicator with separate requests can hit Binance API limits. This app obtains the full symbol universe and 24-hour tickers, then deep-scans the most liquid subset. Increase the subset carefully. Some symbols may not have open-interest history; those symbols receive no OI points.

The score is a heuristic watchlist ranking, **not a prediction or guarantee of a pump**. It does not place orders. Entry/SL/TP are indicative only. Test with paper trading and verify the live chart, spread, liquidity, funding, contract filters, and risk before trading.

## Run on Android
The easiest route is to deploy the app to Streamlit Community Cloud from a GitHub repository, then open the generated app URL in Chrome on Android. You can also run it on a PC with Python.

### Deploy (recommended)
1. Create a GitHub account/repository.
2. Upload `app.py` and `requirements.txt` to the repository root.
3. In Streamlit Community Cloud, create a new app and select that repository and `app.py`.
4. Wait for deployment, then open the app URL on your Android phone.
5. Bookmark the URL or add it to your home screen from Chrome.

Hosting providers and their terms/availability may change. Do not publish secrets in the GitHub repository.

### Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Telegram setup
1. In Telegram, open `@BotFather`, create a bot, and copy its bot token.
2. Open your bot and press Start.
3. Obtain your chat ID using a trusted Telegram bot/API method.
4. Enter the token and chat ID in the app sidebar, then click "Send Top 10 to Telegram".
5. The token is entered into the running app session only; do not share it or commit it to GitHub.

## Binance API
The scanner uses public USDⓈ-M Futures market-data endpoints and does not need a Binance API key:
- `/fapi/v1/exchangeInfo`
- `/fapi/v1/ticker/24hr`
- `/fapi/v1/klines`
- `/fapi/v1/premiumIndex`
- `/futures/data/openInterestHist`

Public endpoints can be rate-limited or unavailable in some regions/networks. The app handles missing OI data by omitting those points.

## Scoring (maximum 100)
- Volume expansion: 20
- Open-interest increase: 20
- EMA trend: 15
- RSI 50–65: 10
- Near resistance: 10
- Breakout close with volume: 5
- Funding condition: 10
- BTC trend: 10

These are initial heuristic weights, not validated probabilities. Backtest and tune before risking money.
